import numpy as np
from flask import Flask, request, jsonify, render_template

import pickle

# Create flask app
app = Flask(__name__)
model = pickle.load(open("model.pkl", "rb"))

@app.route("/")
def Home():
    return render_template("index.html")


@app.route('/predict',methods=['POST', 'GET'])
def predict():
    # int_features=[int(x) for x in request.form.values()]
    # #final=[np.array(int_features)]
    # final = [int_features]
    # print(int_features)
    # print(final)
    
    # prediction=model.predict(final)
    # return render_template("index.html", prediction_text = "the prediction {}{}{}".format(prediction, int_features, final))
    #output='{0:.{1}f}'.format(prediction[0][1], 2)
    int_features = [int(x) for x in request.form.values()]
    final_features = [np.array(int_features)]
    prediction = model.predict(final_features)

    output = (prediction)

    return render_template('index.html', prediction_text='Predicted output $ {}'.format(output))


if __name__ == "__main__":
    app.run(debug=True)