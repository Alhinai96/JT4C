import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
import pickle

# Load the csv file
excel = pd.read_excel("Book2.xlsx", engine = 'openpyxl')

#print(excel.head())

# Select independent and dependent variable
X = excel.drop('Target', axis=1)
y = excel['Target']


# Split the dataset into train and test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.30, random_state=1)

# Feature scaling
# sc = StandardScaler()
# X_train = sc.fit_transform(X_train)
# X_test= sc.transform(X_test)

# Instantiate the model
classifier = RandomForestClassifier()

# Fit the model
classifier.fit(X_train, y_train)
# X_test = [[6, 2, 120, 75,100,65,3,4,1,2009,0]]
# #print(classifier.predict([[6, 3, 91, 71,70,61,3,1,4,2002,2]]))
# y_new = classifier.predict(X_test)
# print(y_new)
# Make pickle file of our model
pickle.dump(classifier, open("model.pkl", "wb"))

model=pickle.load(open('model.pkl','rb'))
#print(model.predict([[6, 2, 120, 75,100,65,3,4,1,2009,9]]))



# pickle.dump(log_reg,open('model.pkl','wb'))
# model=pickle.load(open('model.pkl','rb'))